package com.example.aichatplugin;

/**
 * 共享消息模型
 * 用于统一对话管理和AI服务间的消息格式
 */
public class Message {
    private final String role;
    private final String content;

    public Message(String role, String content) {
        this.role = role;
        this.content = content;
    }

    public String getRole() {
        return role;
    }

    public String getContent() {
        return content;
    }

    @Override
    public String toString() {
        return role + ": " + content;
    }
}
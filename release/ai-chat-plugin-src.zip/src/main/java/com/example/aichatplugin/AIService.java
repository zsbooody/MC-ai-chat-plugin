/**
 * AIService - AI服务类
 * 
 * 这个类负责处理与AI相关的所有操作，包括：
 * 1. 发送消息到AI服务
 * 2. 处理AI响应
 * 3. 管理对话历史
 * 4. 处理环境信息
 * 
 * 主要功能：
 * - 消息处理
 * - 对话管理
 * - 环境感知
 */

package com.example.aichatplugin;

import org.bukkit.entity.Player;

/**
 * AI服务接口
 * 定义了AI服务需要实现的基本方法
 */
public interface AIService {
    /**
     * 生成AI响应
     * 
     * @param prompt 用户输入的提示文本
     * @param player 发送请求的玩家
     * @return AI响应文本
     */
    String generateResponse(String prompt, Player player);

    /**
     * 关闭服务
     * 用于清理资源
     */
    void shutdown();
} 
package com.example.aichatplugin;

import org.bukkit.entity.Player;
import java.util.*;

/**
 * ConversationManager - 对话管理器
 * 
 * 这个类负责管理玩家与AI之间的对话历史，包括：
 * 1. 存储对话记录
 * 2. 管理对话上下文
 * 3. 限制历史记录长度
 * 
 * 主要功能：
 * - 对话历史管理
 * - 上下文维护
 * - 历史记录清理
 */

/**
 * 对话管理器类
 * 
 * 职责：
 * 1. 管理玩家对话历史
 * 2. 限制历史记录长度
 * 3. 提供对话上下文
 */
public class ConversationManager {
    private final Map<UUID, List<String>> conversationHistory;
    private final int maxHistorySize;
    
    /**
     * 构造函数
     * 
     * @param maxHistorySize 最大历史记录长度
     */
    public ConversationManager(int maxHistorySize) {
        this.conversationHistory = new HashMap<>();
        this.maxHistorySize = maxHistorySize;
    }
    
    /**
     * 获取玩家的对话历史
     * 
     * @param player 玩家
     * @return 对话历史列表
     */
    public List<String> getHistory(Player player) {
        return conversationHistory.computeIfAbsent(player.getUniqueId(), k -> new ArrayList<>());
    }
    
    /**
     * 添加消息到对话历史
     * 
     * @param player 玩家
     * @param message 消息内容
     */
    public void addMessage(Player player, String message) {
        List<String> history = getHistory(player);
        history.add(message);
        
        // 如果历史记录超过最大限制，删除最旧的消息
        while (history.size() > maxHistorySize) {
            history.remove(0);
        }
    }
    
    /**
     * 清除指定玩家的对话历史
     * 
     * @param player 玩家
     */
    public void clearHistory(Player player) {
        conversationHistory.remove(player.getUniqueId());
    }
    
    /**
     * 清除所有玩家的对话历史
     */
    public void clearAll() {
        conversationHistory.clear();
    }
}
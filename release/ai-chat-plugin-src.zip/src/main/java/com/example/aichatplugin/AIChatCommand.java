package com.example.aichatplugin;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import java.util.logging.Level;

/**
 * AI聊天命令处理器
 * 处理玩家输入的AI聊天命令
 */
public class AIChatCommand implements CommandExecutor {
    private final AIChatPlugin plugin;

    public AIChatCommand(AIChatPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("该命令只能由玩家执行");
            return true;
        }

        Player player = (Player) sender;
        
        if (args.length == 0) {
            player.sendMessage("用法: /aichat <消息>");
            return true;
        }

        // 构建完整的消息
        StringBuilder message = new StringBuilder();
        for (String arg : args) {
            message.append(arg).append(" ");
        }
        String fullMessage = message.toString().trim();

        try {
            // 获取AI服务并生成响应
            AIService aiService = plugin.getAIService();
            String response = aiService.generateResponse(fullMessage, player);
            player.sendMessage(response);
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "处理AI聊天命令时发生错误", e);
            player.sendMessage("处理命令时发生错误，请稍后重试");
        }

        return true;
    }
} 
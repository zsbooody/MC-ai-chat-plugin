/**
 * SpatialPerceptionService - 空间感知服务
 * 
 * 这个类负责处理空间感知相关的功能，包括：
 * 1. 锥形视野扫描
 * 2. 方块检测
 * 3. 空间信息收集
 * 
 * 主要功能：
 * - 扫描玩家周围环境
 * - 检测方块类型
 * - 提供空间感知
 */

package com.example.aichatplugin;

import org.bukkit.Material;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.Location;
import org.bukkit.util.Vector;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import org.bukkit.World;

/**
 * 空间感知服务类
 * 
 * 职责：
 * 1. 提供空间扫描功能
 * 2. 处理方块检测
 * 3. 生成空间描述
 */
public class SpatialPerceptionService {
    private final AIChatPlugin plugin;
    private static final double DEFAULT_RANGE = 10.0;
    private static final double DEFAULT_SCAN_ANGLE = 90.0;
    private static final int DEFAULT_SCAN_STEPS = 5;
    
    /**
     * 构造函数
     * 
     * @param plugin 插件实例
     */
    public SpatialPerceptionService(AIChatPlugin plugin) {
        this.plugin = plugin;
    }
    
    /**
     * 执行锥形视野扫描
     * 
     * @param player 目标玩家
     * @return 扫描结果描述
     */
    public String performConeVisionScan(Player player) {
        return performConeVisionScan(player, DEFAULT_RANGE, DEFAULT_SCAN_ANGLE, DEFAULT_SCAN_STEPS);
    }
    
    /**
     * 执行锥形视野扫描
     * 
     * @param player 目标玩家
     * @param range 扫描范围
     * @param scanAngle 扫描角度
     * @param scanSteps 扫描步数
     * @return 扫描结果描述
     */
    public String performConeVisionScan(Player player, double range, double scanAngle, int scanSteps) {
        Location playerLoc = player.getLocation();
        World world = player.getWorld();
        StringBuilder result = new StringBuilder();
        
        // 获取玩家朝向
        float yaw = playerLoc.getYaw();
        double angleStep = scanAngle / scanSteps;
        
        // 扫描前方区域
        for (int i = 0; i < scanSteps; i++) {
            double currentAngle = yaw - (scanAngle / 2) + (i * angleStep);
            double radian = Math.toRadians(currentAngle);
            
            // 计算扫描方向
            double dx = Math.sin(radian);
            double dz = Math.cos(radian);
            
            // 扫描距离
            for (double distance = 1; distance <= range; distance++) {
                Location scanLoc = playerLoc.clone().add(dx * distance, 0, dz * distance);
                Block block = scanLoc.getBlock();
                
                // 检查方块是否透明
                if (!block.isPassable() && block.getType().isOccluding()) {
                    result.append(String.format("前方%d格处有%s，", 
                        (int)distance, block.getType().name()));
                    break;
                }
            }
        }
        
        // 检查脚下方块
        Block belowBlock = playerLoc.clone().subtract(0, 1, 0).getBlock();
        result.append(String.format("脚下是%s，", belowBlock.getType().name()));
        
        // 检查头顶方块
        Block aboveBlock = playerLoc.clone().add(0, 1, 0).getBlock();
        result.append(String.format("头顶是%s", aboveBlock.getType().name()));
        
        return result.toString();
    }
    
    public String performPlayerCenteredDetection(Player player) {
        double radius = plugin.getConfig().getDouble("performance.player-centric-detection.radius", 10.0);
        double interval = plugin.getConfig().getDouble("performance.player-centric-detection.interval", 2.0);
        boolean includeEntities = plugin.getConfig().getBoolean("performance.player-centric-detection.include-entities", true);
        
        // 使用配置参数执行探测
        return performPlayerCenteredDetection(player, radius, interval, includeEntities);
    }
    
    public String performPlayerCenteredDetection(Player player, double radius, double interval, boolean includeEntities) {
        Location center = player.getLocation().clone();
        List<String> nearbyObjects = new ArrayList<>();
        
        // 玩家中心探测
        for (double x = -radius; x <= radius; x += interval) {
            for (double z = -radius; z <= radius; z += interval) {
                Location checkLoc = center.clone().add(x, 0, z);
                Block block = checkLoc.getBlock();
                
                if (!block.isPassable() && !block.getType().isAir()) {
                    nearbyObjects.add(String.format("%s (%.1f, %.1f, %.1f)", 
                        block.getType(), checkLoc.getX(), checkLoc.getY(), checkLoc.getZ()));
                }
            }
        }
        
        // 实体检测（在主线程执行同步API）
        if (includeEntities) {
            CompletableFuture<Void> entityFuture = CompletableFuture.runAsync(() -> {
                Bukkit.getScheduler().runTask(plugin, () -> {
                    for (Entity entity : player.getNearbyEntities(radius, radius, radius)) {
                        if (entity != player) {
                            Location loc = entity.getLocation();
                            nearbyObjects.add(String.format("%s (%.1f, %.1f, %.1f)", 
                                entity.getType(), loc.getX(), loc.getY(), loc.getZ()));
                        }
                    }
                });
            });
            try {
                entityFuture.get(); // 等待主线程任务完成
            } catch (InterruptedException | ExecutionException e) {
                plugin.getLogger().severe("实体检测异常: " + e.getMessage());
            }
        }
        
        return "附近物体:\n" + String.join("\n", nearbyObjects);
    }
    
    /**
     * 获取周围实体信息
     * 
     * @param location 中心位置
     * @param range 检测范围
     * @return 实体信息列表
     */
    public List<String> getNearbyEntities(Location location, int range) {
        List<String> entities = new ArrayList<>();
        World world = location.getWorld();
        
        if (world == null) {
            return entities;
        }
        
        for (Entity entity : world.getNearbyEntities(location, range, range, range)) {
            if (entity instanceof Player) {
                continue;
            }
            
            String type = entity.getType().name();
            double distance = entity.getLocation().distance(location);
            entities.add(String.format("%s (%.1f格)", type, distance));
        }
        
        return entities;
    }
    
    /**
     * 获取空间结构信息
     * 
     * @param location 中心位置
     * @param range 检测范围
     * @return 空间结构信息
     */
    public Map<String, Integer> getSpatialStructure(Location location, int range) {
        Map<String, Integer> structure = new HashMap<>();
        World world = location.getWorld();
        
        if (world == null) {
            return structure;
        }
        
        for (int x = -range; x <= range; x++) {
            for (int y = -range; y <= range; y++) {
                for (int z = -range; z <= range; z++) {
                    Location blockLoc = location.clone().add(x, y, z);
                    String type = blockLoc.getBlock().getType().name();
                    structure.merge(type, 1, Integer::sum);
                }
            }
        }
        
        return structure;
    }
}
/**
 * TimeListener - 游戏时间监听器
 * 
 * 这个类负责监听Minecraft世界的时间变化，并在特定时间点（黎明、中午、黄昏、午夜）
 * 触发AI响应。主要功能包括：
 * 1. 监控世界时间变化
 * 2. 在特定时间点触发AI响应
 * 3. 收集环境信息
 * 4. 广播AI消息
 */

package com.example.aichatplugin;

import org.bukkit.World;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.world.TimeSkipEvent;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import org.bukkit.entity.Player;

/**
 * 时间监听器
 * 监听游戏时间变化事件
 */
public class TimeListener implements Listener {
    private final AIChatPlugin plugin;
    private final AIService aiService;
    private final Set<Long> processedTimes = new HashSet<>();

    public TimeListener(AIChatPlugin plugin, AIService aiService) {
        this.plugin = plugin;
        this.aiService = aiService;
    }

    @EventHandler
    public void onTimeSkip(TimeSkipEvent event) {
        World world = event.getWorld();
        long time = world.getTime();
        
        // 检查是否是昼夜交替时间
        if (isDayNightTransition(time) && !processedTimes.contains(time)) {
            processedTimes.add(time);
            
            // 清理已处理的时间记录，防止内存溢出
            if (processedTimes.size() > 100) {
                processedTimes.clear();
            }
            
            String timeOfDay = time < 13000 ? "白天" : "夜晚";
            String prompt = String.format("游戏时间变为了%s", timeOfDay);
            
            // 为每个在线玩家生成响应
            for (Player player : world.getPlayers()) {
                try {
                    String response = aiService.generateResponse(prompt, player);
                    player.sendMessage(response);
                } catch (Exception e) {
                    plugin.getLogger().log(Level.SEVERE, "处理时间变化事件时发生错误", e);
                }
            }
        }
    }

    private boolean isDayNightTransition(long time) {
        // 检查是否接近昼夜交替时间点
        return (time >= 12900 && time <= 13100) || // 夜晚到白天
               (time >= 22900 && time <= 23100);   // 白天到夜晚
    }
}
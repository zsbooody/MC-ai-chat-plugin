package com.example.aichatplugin;

import org.bukkit.entity.Player;
import org.bukkit.entity.Entity;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.Material;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

/**
 * 环境信息收集器
 * 
 * 职责：
 * 1. 收集玩家周围的环境信息
 * 2. 统计实体数量
 * 3. 记录天气和时间
 * 4. 生成环境报告
 */
public class EnvironmentInfoCollector {
    private final SpatialPerceptionService spatialService;
    private final AIChatPlugin plugin;
    
    public EnvironmentInfoCollector(SpatialPerceptionService spatialService, AIChatPlugin plugin) {
        this.spatialService = spatialService;
        this.plugin = plugin;
    }
    
    /**
     * 收集环境信息
     * 
     * @param player 目标玩家
     * @return 环境信息字符串
     */
    public String collectEnvironmentInfo(Player player) {
        StringBuilder info = new StringBuilder();
        
        // 收集位置信息
        Location loc = player.getLocation();
        if (plugin.getConfig().getBoolean("environment.show-detailed-location", true)) {
            info.append(String.format("位置: %.1f, %.1f, %.1f\n", 
                loc.getX(), loc.getY(), loc.getZ()));
        }
        
        // 收集世界信息
        World world = player.getWorld();
        info.append(String.format("世界: %s\n", world.getName()));
        
        // 收集天气信息
        if (plugin.getConfig().getBoolean("environment.show-weather", true)) {
            info.append(String.format("天气: %s\n", 
                world.isClearWeather() ? "晴朗" : 
                world.isThundering() ? "雷暴" : "下雨"));
        }
        
        // 收集时间信息
        if (plugin.getConfig().getBoolean("environment.show-time", true)) {
            long time = world.getTime();
            info.append(String.format("时间: %s\n", 
                time < 13000 ? "白天" : "夜晚"));
        }
        
        // 收集周围方块信息
        info.append("周围方块: ");
        List<String> blocks = collectNearbyBlocks(player);
        info.append(String.join(", ", blocks));
        info.append("\n");
        
        // 收集周围实体信息
        info.append("周围实体: ");
        Map<String, Integer> entities = collectNearbyEntities(player);
        List<String> entityInfo = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : entities.entrySet()) {
            entityInfo.add(String.format("%sx%d", entry.getKey(), entry.getValue()));
        }
        info.append(String.join(", ", entityInfo));
        
        return info.toString();
    }
    
    /**
     * 收集周围方块信息
     * 
     * @param player 目标玩家
     * @return 方块列表
     */
    private List<String> collectNearbyBlocks(Player player) {
        List<String> blocks = new ArrayList<>();
        Location loc = player.getLocation();
        int range = plugin.getConfig().getInt("environment.block-detection-range", 3);
        
        // 检查周围区域
        for (int x = -range; x <= range; x++) {
            for (int y = -range; y <= range; y++) {
                for (int z = -range; z <= range; z++) {
                    Block block = loc.clone().add(x, y, z).getBlock();
                    if (block.getType() != Material.AIR) {
                        blocks.add(block.getType().name());
                    }
                }
            }
        }
        
        return blocks;
    }
    
    /**
     * 收集周围实体信息
     * 
     * @param player 目标玩家
     * @return 实体统计
     */
    private Map<String, Integer> collectNearbyEntities(Player player) {
        Map<String, Integer> entityCount = new HashMap<>();
        int range = plugin.getConfig().getInt("environment.entity-detection-range", 10);
        
        // 获取范围内的实体
        for (Entity entity : player.getNearbyEntities(range, range, range)) {
            String type = entity.getType().name();
            entityCount.merge(type, 1, Integer::sum);
        }
        
        return entityCount;
    }
} 
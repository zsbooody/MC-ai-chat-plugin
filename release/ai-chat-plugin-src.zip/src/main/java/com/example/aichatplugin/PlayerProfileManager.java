/**
 * PlayerProfileManager - 玩家档案管理器
 * 
 * 这个类负责管理玩家的档案信息，包括：
 * 1. 玩家基本信息
 * 2. 游戏统计数据
 * 3. 成就记录
 * 4. 行为分析
 * 
 * 主要功能：
 * - 档案管理
 * - 数据分析
 * - 行为追踪
 */

package com.example.aichatplugin;

import org.bukkit.entity.Player;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.HashMap;

/**
 * 玩家档案管理器
 * 
 * 职责：
 * 1. 管理玩家档案信息
 * 2. 提供玩家状态查询
 * 3. 维护玩家数据
 */
public class PlayerProfileManager {
    private final AIChatPlugin plugin;
    private final Map<UUID, PlayerProfile> profiles;
    private final AIService aiService;
    private final List<String> playerHistory;
    
    public PlayerProfileManager(AIChatPlugin plugin, AIService aiService) {
        this.plugin = plugin;
        this.profiles = new HashMap<>();
        this.aiService = aiService;
        this.playerHistory = new ArrayList<>();
        plugin.debug("PlayerProfileManager初始化完成");
    }
    
    /**
     * 获取玩家档案
     */
    public PlayerProfile getProfile(Player player) {
        return profiles.computeIfAbsent(player.getUniqueId(), uuid -> new PlayerProfile(player));
    }
    
    /**
     * 更新玩家档案
     */
    public void updateProfile(Player player) {
        PlayerProfile profile = getProfile(player);
        profile.update(player);
        plugin.verbose("更新玩家档案: " + player.getName());
    }
    
    /**
     * 获取玩家档案报告
     * 
     * @param player 玩家对象
     * @return 档案报告
     */
    public String getProfileReport(Player player) {
        PlayerProfile profile = getProfile(player);
        String report = generateReport(profile);
        
        // 使用AI分析报告
        String prompt = "请分析以下玩家档案报告，并给出简要评价：\n" + report;
        
        try {
            return aiService.generateResponse(prompt, player);
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "生成玩家档案报告时发生错误", e);
            return "生成玩家档案报告时发生错误";
        }
    }
    
    /**
     * 生成档案报告
     * 
     * @param profile 玩家档案
     * @return 报告文本
     */
    private String generateReport(PlayerProfile profile) {
        StringBuilder report = new StringBuilder();
        report.append("玩家档案报告\n");
        report.append("==========\n");
        report.append("玩家名称: ").append(profile.getName()).append("\n");
        report.append("游戏时长: ").append(profile.getPlayTime()).append(" 分钟\n");
        report.append("击杀数: ").append(profile.getKills()).append("\n");
        report.append("死亡数: ").append(profile.getDeaths()).append("\n");
        report.append("挖掘方块数: ").append(profile.getBlocksMined()).append("\n");
        report.append("放置方块数: ").append(profile.getBlocksPlaced()).append("\n");
        report.append("行走距离: ").append(profile.getDistanceWalked()).append(" 米\n");
        report.append("==========\n");
        return report.toString();
    }
    
    /**
     * 玩家档案类
     */
    public static class PlayerProfile {
        private final UUID uuid;
        private String name;
        private int level;
        private double health;
        private double maxHealth;
        private int foodLevel;
        private String world;
        private double x, y, z;
        private int playTime;
        private int kills;
        private int deaths;
        private int blocksMined;
        private int blocksPlaced;
        private double distanceWalked;
        
        public PlayerProfile(Player player) {
            this.uuid = player.getUniqueId();
            update(player);
        }
        
        public void update(Player player) {
            this.name = player.getName();
            this.level = player.getLevel();
            this.health = player.getHealth();
            this.maxHealth = player.getMaxHealth();
            this.foodLevel = player.getFoodLevel();
            this.world = player.getWorld().getName();
            this.x = player.getLocation().getX();
            this.y = player.getLocation().getY();
            this.z = player.getLocation().getZ();
            this.playTime = 0; // Assuming playTime is not available in the Player object
            this.kills = 0;
            this.deaths = 0;
            this.blocksMined = 0;
            this.blocksPlaced = 0;
            this.distanceWalked = 0.0;
        }
        
        public UUID getUuid() {
            return uuid;
        }
        
        public String getName() {
            return name;
        }
        
        public int getLevel() {
            return level;
        }
        
        public double getHealth() {
            return health;
        }
        
        public double getMaxHealth() {
            return maxHealth;
        }
        
        public int getFoodLevel() {
            return foodLevel;
        }
        
        public String getWorld() {
            return world;
        }
        
        public double getX() {
            return x;
        }
        
        public double getY() {
            return y;
        }
        
        public double getZ() {
            return z;
        }
        
        public int getPlayTime() {
            return playTime;
        }
        
        public int getKills() {
            return kills;
        }
        
        public int getDeaths() {
            return deaths;
        }
        
        public int getBlocksMined() {
            return blocksMined;
        }
        
        public int getBlocksPlaced() {
            return blocksPlaced;
        }
        
        public double getDistanceWalked() {
            return distanceWalked;
        }
        
        public void updateData(Map<String, Object> data) {
            if (data.containsKey("playTime")) {
                playTime = (int) data.get("playTime");
            }
            if (data.containsKey("kills")) {
                kills = (int) data.get("kills");
            }
            if (data.containsKey("deaths")) {
                deaths = (int) data.get("deaths");
            }
            if (data.containsKey("blocksMined")) {
                blocksMined = (int) data.get("blocksMined");
            }
            if (data.containsKey("blocksPlaced")) {
                blocksPlaced = (int) data.get("blocksPlaced");
            }
            if (data.containsKey("distanceWalked")) {
                distanceWalked = (double) data.get("distanceWalked");
            }
        }
    }

    public void addToHistory(String message) {
        playerHistory.add(message);
        // 保持历史记录在合理范围内
        if (playerHistory.size() > 100) {
            playerHistory.remove(0);
        }
    }

    public String generateProfile(Player player) {
        StringBuilder prompt = new StringBuilder();
        prompt.append("玩家档案信息：\n");
        prompt.append("名称：").append(player.getName()).append("\n");
        prompt.append("等级：").append(player.getLevel()).append("\n");
        prompt.append("经验值：").append(player.getExp()).append("\n");
        prompt.append("生命值：").append(player.getHealth()).append("/").append(player.getMaxHealth()).append("\n");
        prompt.append("位置：").append(player.getLocation().getBlockX()).append(", ")
              .append(player.getLocation().getBlockY()).append(", ")
              .append(player.getLocation().getBlockZ()).append("\n");
        
        // 添加历史对话
        if (!playerHistory.isEmpty()) {
            prompt.append("\n最近的对话历史：\n");
            for (String history : playerHistory) {
                prompt.append("- ").append(history).append("\n");
            }
        }

        try {
            return aiService.generateResponse(prompt.toString(), player);
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "生成玩家档案时发生错误", e);
            return "生成玩家档案时发生错误";
        }
    }
}

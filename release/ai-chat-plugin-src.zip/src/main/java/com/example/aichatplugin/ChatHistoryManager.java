package com.example.aichatplugin;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 对话历史管理器
 * 
 * 职责：
 * 1. 管理每个玩家的对话历史
 * 2. 维护对话上下文
 * 3. 提供对话历史查询和清理功能
 */
public class ChatHistoryManager {
    private final AIChatPlugin plugin;
    private final Map<UUID, List<ChatMessage>> chatHistory;
    private final int maxHistorySize;
    
    public ChatHistoryManager(AIChatPlugin plugin) {
        this.plugin = plugin;
        this.chatHistory = new ConcurrentHashMap<>();
        this.maxHistorySize = plugin.getConfig().getInt("chat.max-history", 5);
        
        plugin.debug("ChatHistoryManager初始化完成");
        plugin.verbose("最大历史记录数: " + maxHistorySize);
    }
    
    /**
     * 添加新的对话消息
     */
    public void addMessage(UUID playerId, String playerName, String message, boolean isPlayer) {
        chatHistory.computeIfAbsent(playerId, k -> new ArrayList<>())
            .add(new ChatMessage(playerName, message, isPlayer));
        
        // 如果超过最大历史记录数，删除最旧的消息
        List<ChatMessage> history = chatHistory.get(playerId);
        if (history.size() > maxHistorySize) {
            history.remove(0);
        }
        
        plugin.debug("添加新消息到玩家 " + playerName + " 的历史记录");
        plugin.verbose("当前历史记录大小: " + history.size());
    }
    
    /**
     * 获取最近的对话上下文
     */
    public String getRecentContext(UUID playerId) {
        List<ChatMessage> history = chatHistory.get(playerId);
        if (history == null || history.isEmpty()) {
            return "";
        }
        
        StringBuilder context = new StringBuilder("最近的对话历史：\n");
        for (ChatMessage msg : history) {
            context.append(msg.toString()).append("\n");
        }
        
        return context.toString();
    }
    
    /**
     * 清理玩家的对话历史
     */
    public void clearHistory(UUID playerId) {
        chatHistory.remove(playerId);
        plugin.debug("已清理玩家 " + playerId + " 的对话历史");
    }
    
    /**
     * 清理所有对话历史
     */
    public void clearAllHistory() {
        chatHistory.clear();
        plugin.debug("已清理所有对话历史");
    }
    
    /**
     * 对话消息类
     */
    private static class ChatMessage {
        private final String playerName;
        private final String message;
        private final boolean isPlayer;
        private final long timestamp;
        
        public ChatMessage(String playerName, String message, boolean isPlayer) {
            this.playerName = playerName;
            this.message = message;
            this.isPlayer = isPlayer;
            this.timestamp = System.currentTimeMillis();
        }
        
        @Override
        public String toString() {
            return String.format("%s %s: %s",
                isPlayer ? "玩家" : "AI",
                playerName,
                message);
        }
    }
} 
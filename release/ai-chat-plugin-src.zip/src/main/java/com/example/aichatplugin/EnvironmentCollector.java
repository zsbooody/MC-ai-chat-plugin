package com.example.aichatplugin;

import org.bukkit.entity.Player;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.block.Block;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/**
 * 环境信息收集器
 * 
 * 职责：
 * 1. 收集玩家周围的环境信息
 * 2. 缓存环境信息以提高性能
 * 3. 定期更新缓存
 */
public class EnvironmentCollector {
    private final AIChatPlugin plugin;
    private final Map<String, CachedEnvironmentInfo> environmentCache;
    private static final long CACHE_DURATION = 2000; // 缓存持续时间（毫秒）
    
    public EnvironmentCollector(AIChatPlugin plugin) {
        this.plugin = plugin;
        this.environmentCache = new ConcurrentHashMap<>();
    }
    
    /**
     * 收集环境信息
     * 
     * @param player 玩家对象
     * @return 环境信息字符串
     */
    public String collectEnvironmentInfo(Player player) {
        String playerName = player.getName();
        CachedEnvironmentInfo cachedInfo = environmentCache.get(playerName);
        
        // 检查缓存是否有效
        if (cachedInfo != null && !cachedInfo.isExpired()) {
            plugin.debug("使用缓存的环境信息");
            return cachedInfo.getInfo();
        }
        
        // 收集新的环境信息
        plugin.debug("收集新的环境信息");
        StringBuilder info = new StringBuilder();
        
        try {
            // 位置信息
            Location loc = player.getLocation();
            info.append(String.format("位置: %.1f, %.1f, %.1f\n", 
                loc.getX(), loc.getY(), loc.getZ()));
            
            // 世界信息
            World world = player.getWorld();
            info.append(String.format("世界: %s\n", world.getName()));
            info.append(String.format("时间: %d\n", world.getTime()));
            info.append(String.format("天气: %s\n", world.hasStorm() ? "下雨" : "晴朗"));
            
            // 周围方块
            int blockRange = plugin.getConfig().getInt("environment.block-detection-range", 3);
            List<String> nearbyBlocks = new ArrayList<>();
            for (int x = -blockRange; x <= blockRange; x++) {
                for (int y = -blockRange; y <= blockRange; y++) {
                    for (int z = -blockRange; z <= blockRange; z++) {
                        Block block = loc.clone().add(x, y, z).getBlock();
                        if (!block.isPassable() && !block.getType().isAir()) {
                            nearbyBlocks.add(block.getType().name());
                        }
                    }
                }
            }
            if (!nearbyBlocks.isEmpty()) {
                info.append("周围方块: ").append(String.join(", ", nearbyBlocks)).append("\n");
            }
            
            // 周围实体
            int entityRange = plugin.getConfig().getInt("environment.entity-detection-range", 10);
            List<String> nearbyEntities = new ArrayList<>();
            for (Entity entity : player.getNearbyEntities(entityRange, entityRange, entityRange)) {
                if (entity != player) {
                    nearbyEntities.add(entity.getType().name());
                }
            }
            if (!nearbyEntities.isEmpty()) {
                info.append("周围实体: ").append(String.join(", ", nearbyEntities)).append("\n");
            }
            
            // 更新缓存
            String environmentInfo = info.toString();
            environmentCache.put(playerName, new CachedEnvironmentInfo(environmentInfo));
            
            return environmentInfo;
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "收集环境信息时发生错误", e);
            return "无法收集环境信息";
        }
    }
    
    /**
     * 缓存的环境信息类
     */
    private static class CachedEnvironmentInfo {
        private final String info;
        private final long timestamp;
        
        public CachedEnvironmentInfo(String info) {
            this.info = info;
            this.timestamp = System.currentTimeMillis();
        }
        
        public String getInfo() {
            return info;
        }
        
        public boolean isExpired() {
            return System.currentTimeMillis() - timestamp > CACHE_DURATION;
        }
    }
} 
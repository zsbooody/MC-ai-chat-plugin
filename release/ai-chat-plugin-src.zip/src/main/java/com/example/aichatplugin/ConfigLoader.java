package com.example.aichatplugin;

import java.io.File;  // 修复"找不到符号 类File"的问题

public class ConfigLoader {
    private final File dataFolder;

    public ConfigLoader(File dataFolder) {
        this.dataFolder = dataFolder;
    }

    public static String getApiKey() {
        // 实现配置加载逻辑（例如从dataFolder读取配置文件）
        return ""; // 临时返回空，需根据实际配置逻辑完善
    }
}
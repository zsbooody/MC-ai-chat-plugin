/**
 * PlayerStatusListener - 玩家状态监听器
 * 
 * 这个类负责监听玩家的各种状态变化，包括：
 * 1. 玩家加入服务器
 * 2. 玩家离开服务器
 * 3. 玩家受到伤害
 * 4. 玩家状态变化
 * 
 * 主要功能：
 * - 收集玩家状态信息
 * - 触发AI响应
 * - 广播状态变化消息
 */

package com.example.aichatplugin;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerLevelChangeEvent;
import org.bukkit.event.player.PlayerAdvancementDoneEvent;
import org.bukkit.event.player.PlayerExpChangeEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.Location;
import java.util.UUID;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.HashMap;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.logging.Level;

/**
 * 玩家状态监听器
 * 
 * 职责：
 * 1. 监听玩家状态变化
 * 2. 更新玩家档案
 * 3. 触发AI响应
 */
public class PlayerStatusListener implements Listener {
    private final AIChatPlugin plugin;
    private final AIService aiService;
    private final PlayerProfileManager profileManager;
    private final Map<UUID, Long> lastExpTime = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastLowHealthTime = new ConcurrentHashMap<>();
    private static final long EXP_COOLDOWN = 3000; // 3秒冷却
    private static final long LOW_HEALTH_COOLDOWN = 5000; // 5秒冷却
    
    public PlayerStatusListener(AIChatPlugin plugin, AIService aiService, PlayerProfileManager profileManager) {
        this.plugin = plugin;
        this.aiService = aiService;
        this.profileManager = profileManager;
        plugin.debug("PlayerStatusListener初始化完成");
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        if (!plugin.getConfig().getBoolean("player-status.respond-to-join", true)) {
            return;
        }
        
        Player player = event.getPlayer();
        profileManager.updateProfile(player);
        
        // 发送格式化消息
        String message = plugin.getConfig().getString("messages.join", "&a{player}加入了游戏")
            .replace("{player}", player.getName());
        player.sendMessage(message);
        
        // 添加AI响应
        try {
            String prompt = String.format("玩家 %s 加入了游戏，欢迎他", player.getName());
            String response = aiService.generateResponse(prompt, player);
            player.sendMessage(response);
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "处理玩家加入事件时发生错误", e);
        }
        
        plugin.debug("玩家加入: " + player.getName());
    }
    
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        if (!plugin.getConfig().getBoolean("player-status.respond-to-quit", true)) {
            return;
        }
        
        Player player = event.getPlayer();
        
        // 发送格式化消息
        String message = plugin.getConfig().getString("messages.quit", "&c{player}离开了游戏")
            .replace("{player}", player.getName());
        player.sendMessage(message);
        
        // 添加AI响应
        try {
            String prompt = String.format("玩家 %s 离开了游戏，向他告别", player.getName());
            String response = aiService.generateResponse(prompt, player);
            player.sendMessage(response);
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "处理玩家离开事件时发生错误", e);
        }
        
        plugin.debug("玩家离开: " + player.getName());
    }
    
    @EventHandler
    public void onPlayerDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) {
            return;
        }
        
        Player player = (Player) event.getEntity();
        UUID playerId = player.getUniqueId();
        long currentTime = System.currentTimeMillis();
        
        // 检查冷却时间
        if (lastLowHealthTime.containsKey(playerId)) {
            long lastTime = lastLowHealthTime.get(playerId);
            if (currentTime - lastTime < LOW_HEALTH_COOLDOWN) {
                return;
            }
        }
        
        // 检查是否达到低血量阈值
        double healthThreshold = plugin.getConfig().getDouble("player-status.damage-threshold", 0.3);
        double currentHealth = player.getHealth();
        double maxHealth = player.getMaxHealth();
        double healthPercentage = currentHealth / maxHealth;
        
        if (healthPercentage <= healthThreshold) {
            lastLowHealthTime.put(playerId, currentTime);
            try {
                String prompt = String.format("玩家 %s 的生命值较低（%.1f/%.1f），需要帮助", 
                    player.getName(), currentHealth, maxHealth);
                String response = aiService.generateResponse(prompt, player);
                player.sendMessage(response);
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "处理玩家低血量事件时发生错误", e);
            }
        }
    }
    
    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        if (!plugin.getConfig().getBoolean("player-status.respond-to-death", true)) {
            return;
        }
        
        Player player = event.getEntity();
        String location = String.format("%.1f, %.1f, %.1f",
            player.getLocation().getX(),
            player.getLocation().getY(),
            player.getLocation().getZ());
            
        String message = plugin.getConfig().getString("messages.death", "&c{player}在{location}死亡: {reason}")
            .replace("{player}", player.getName())
            .replace("{location}", location)
            .replace("{reason}", event.getDeathMessage());
        player.sendMessage(message);
        
        plugin.debug("玩家死亡: " + player.getName());
    }
    
    @EventHandler
    public void onPlayerLevelChange(PlayerLevelChangeEvent event) {
        if (!plugin.getConfig().getBoolean("player-status.respond-to-level-up", true)) {
            return;
        }
        
        Player player = event.getPlayer();
        int oldLevel = event.getOldLevel();
        int newLevel = event.getNewLevel();
        
        if (newLevel > oldLevel) {
            String message = plugin.getConfig().getString("messages.level-up", "&e{player}的等级从{old_level}提升到{new_level}")
                .replace("{player}", player.getName())
                .replace("{old_level}", String.valueOf(oldLevel))
                .replace("{new_level}", String.valueOf(newLevel));
            player.sendMessage(message);
            
            plugin.debug("玩家升级: " + player.getName() + " " + oldLevel + " -> " + newLevel);
        }
    }
    
    @EventHandler
    public void onPlayerExpChange(PlayerExpChangeEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        long currentTime = System.currentTimeMillis();
        
        // 检查冷却时间
        if (lastExpTime.containsKey(playerId)) {
            long lastTime = lastExpTime.get(playerId);
            if (currentTime - lastTime < EXP_COOLDOWN) {
                return;
            }
        }
        
        lastExpTime.put(playerId, currentTime);
        int amount = event.getAmount();
        
        // 在主线程中处理AI响应
        try {
            String prompt = String.format("玩家 %s 获得了 %d 点经验值", player.getName(), amount);
            String response = aiService.generateResponse(prompt, player);
            player.sendMessage(response);
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "处理玩家经验值变化事件时发生错误", e);
        }
    }
    
    @EventHandler
    public void onPlayerAdvancement(PlayerAdvancementDoneEvent event) {
        if (!plugin.getConfig().getBoolean("player-status.respond-to-advancement", true)) {
            return;
        }
        
        Player player = event.getPlayer();
        String advancement = event.getAdvancement().getKey().getKey();
        
        // 处理成就名称
        String displayName = advancement;
        if (advancement.contains("/")) {
            String[] parts = advancement.split("/");
            displayName = parts[parts.length - 1]
                .replace("_", " ")
                .toLowerCase();
            
            // 首字母大写
            if (!displayName.isEmpty()) {
                displayName = displayName.substring(0, 1).toUpperCase() + displayName.substring(1);
            }
        }
        
        String message = plugin.getConfig().getString("messages.advancement", "&6{player}完成了进度：{advancement}")
            .replace("{player}", player.getName())
            .replace("{advancement}", displayName);
        player.sendMessage(message);
        
        plugin.debug("玩家完成进度: " + player.getName() + " - " + displayName);
    }
}

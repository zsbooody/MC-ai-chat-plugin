/**
 * DirectionUtils - 方向工具类
 * 
 * 这个类提供方向相关的工具方法，主要用于：
 * 1. 角度到方向名称的转换
 * 2. 方向判断和计算
 * 
 * 主要功能：
 * - 将角度值转换为方向名称（北、东、南、西）
 * - 处理角度标准化
 */

package com.example.aichatplugin;

/**
 * 方向工具类
 * 
 * 职责：
 * 1. 提供方向转换功能
 * 2. 处理角度计算
 * 3. 标准化方向表示
 */
public class DirectionUtils {
    
    /**
     * 将角度转换为方向名称
     * 
     * 角度范围：
     * - 315° ~ 45°: 北
     * - 45° ~ 135°: 东
     * - 135° ~ 225°: 南
     * - 225° ~ 315°: 西
     * 
     * @param angle 角度值（可以是float或double类型）
     * @return 方向名称（北、东、南、西）
     */
    public static String getDirectionName(double angle) {
        // 将角度转换为0-360的范围
        double rotation = (angle + 360) % 360;
        if (rotation < 0) {
            rotation += 360.0;
        }
        
        // 根据角度确定方向
        if (rotation >= 315 || rotation < 45) {
            return "北";
        } else if (rotation >= 45 && rotation < 135) {
            return "东";
        } else if (rotation >= 135 && rotation < 225) {
            return "南";
        } else if (rotation >= 225 && rotation < 315) {
            return "西";
        } else {
            return "未知方向";
        }
    }
} 
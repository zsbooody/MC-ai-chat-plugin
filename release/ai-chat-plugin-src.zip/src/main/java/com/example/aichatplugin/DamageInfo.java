package com.example.aichatplugin;

public class DamageInfo {
    private final String cause;
    private final String damager;

    public DamageInfo(String cause, String damager) {
        this.cause = cause;
        this.damager = damager;
    }

    public String getCause() { return cause; }
    public String getDamager() { return damager; }

    @Override
    public String toString() {
        return "伤害原因: " + cause + ", 来源: " + damager;
    }
}
/**
 * DeepSeekAIService - DeepSeek AI服务
 * 
 * 这个类负责与DeepSeek AI服务进行交互，包括：
 * 1. 发送请求到AI服务
 * 2. 处理AI响应
 * 3. 错误处理
 * 
 * 主要功能：
 * - API调用
 * - 响应处理
 * - 错误处理
 */

package com.example.aichatplugin;

import org.bukkit.entity.Player;
import org.json.JSONObject;
import org.json.JSONArray;
import okhttp3.*;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * DeepSeek AI服务实现
 * 
 * 职责：
 * 1. 处理与DeepSeek AI API的通信
 * 2. 优化请求和响应处理
 * 3. 提供高效的AI响应生成
 */
public class DeepSeekAIService implements AIService {
    private final AIChatPlugin plugin;
    private final String apiKey;
    private final String model;
    private final OkHttpClient client;
    private final String apiUrl;
    private final String systemPrompt;
    private final double temperature;
    private final int maxTokens;
    
    public DeepSeekAIService(AIChatPlugin plugin) {
        this.plugin = plugin;
        this.apiKey = plugin.getConfig().getString("settings.api-key");
        this.model = plugin.getConfig().getString("settings.model", "deepseek-chat");
        this.apiUrl = plugin.getConfig().getString("settings.api-url", "https://api.deepseek.com/v1/chat/completions");
        this.systemPrompt = plugin.getConfig().getString("settings.role-system");
        this.temperature = plugin.getConfig().getDouble("settings.temperature", 0.7);
        this.maxTokens = plugin.getConfig().getInt("settings.max-tokens", 150);
        
        // 配置HTTP客户端
        int connectTimeout = plugin.getConfig().getInt("settings.connect-timeout", 5);
        int readTimeout = plugin.getConfig().getInt("settings.read-timeout", 10);
        int writeTimeout = plugin.getConfig().getInt("settings.write-timeout", 10);
        
        this.client = new OkHttpClient.Builder()
            .connectTimeout(connectTimeout, TimeUnit.SECONDS)
            .readTimeout(readTimeout, TimeUnit.SECONDS)
            .writeTimeout(writeTimeout, TimeUnit.SECONDS)
            .build();
            
        plugin.debug("DeepSeekAIService初始化完成");
        plugin.verbose("API密钥长度: " + (apiKey != null ? apiKey.length() : 0));
        plugin.verbose("使用模型: " + model);
        plugin.verbose("API URL: " + apiUrl);
        plugin.verbose("温度参数: " + temperature);
        plugin.verbose("最大令牌数: " + maxTokens);
    }
    
    @Override
    public String generateResponse(String prompt, Player player) {
        plugin.debug("开始生成AI响应");
        plugin.verbose("提示词: " + prompt);
        
        try {
            // 构建请求体
            JSONObject requestBody = new JSONObject();
            requestBody.put("model", model);
            
            JSONArray messages = new JSONArray();
            JSONObject systemMessage = new JSONObject();
            systemMessage.put("role", "system");
            systemMessage.put("content", systemPrompt);
            messages.put(systemMessage);
            
            JSONObject userMessage = new JSONObject();
            userMessage.put("role", "user");
            userMessage.put("content", prompt);
            messages.put(userMessage);
            
            requestBody.put("messages", messages);
            requestBody.put("temperature", temperature);
            requestBody.put("max_tokens", maxTokens);
            
            plugin.verbose("请求体: " + requestBody.toString());
            
            // 发送请求
            Request request = new Request.Builder()
                .url(apiUrl)
                .addHeader("Authorization", "Bearer " + apiKey)
                .addHeader("Content-Type", "application/json")
                .post(RequestBody.create(
                    MediaType.parse("application/json"),
                    requestBody.toString()
                ))
                .build();
                
            // 执行请求
            try (Response response = client.newCall(request).execute()) {
                plugin.debug("收到AI响应");
                plugin.verbose("响应状态码: " + response.code());
                
                if (!response.isSuccessful()) {
                    String errorBody = response.body() != null ? response.body().string() : "未知错误";
                    plugin.getLogger().severe("AI API请求失败: " + errorBody);
                    return plugin.getConfig().getString("messages.error", "&c错误&f: {text}")
                        .replace("{text}", "我现在无法回答。请稍后再试。");
                }
                
                String responseBody = response.body().string();
                plugin.verbose("响应内容: " + responseBody);
                
                JSONObject jsonResponse = new JSONObject(responseBody);
                JSONArray choices = jsonResponse.getJSONArray("choices");
                if (choices.length() > 0) {
                    JSONObject choice = choices.getJSONObject(0);
                    JSONObject message = choice.getJSONObject("message");
                    String content = message.getString("content");
                    return content;
                }
                
                return plugin.getConfig().getString("messages.error", "&c错误&f: {text}")
                    .replace("{text}", "我没有得到有效的回答。");
            }
        } catch (IOException e) {
            plugin.getLogger().severe("调用AI API时发生错误: " + e.getMessage());
            e.printStackTrace();
            return plugin.getConfig().getString("messages.error", "&c错误&f: {text}")
                .replace("{text}", "发生了网络错误。请稍后再试。");
        } catch (Exception e) {
            plugin.getLogger().severe("处理AI响应时发生错误: " + e.getMessage());
            e.printStackTrace();
            return plugin.getConfig().getString("messages.error", "&c错误&f: {text}")
                .replace("{text}", "处理响应时发生错误。请稍后再试。");
        }
    }
    
    @Override
    public void shutdown() {
        // OkHttpClient不需要显式关闭
        plugin.debug("DeepSeekAIService已关闭");
    }
}
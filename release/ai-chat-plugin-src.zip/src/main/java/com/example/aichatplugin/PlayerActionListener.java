package com.example.aichatplugin;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerItemBreakEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Location; // 添加这行
import org.bukkit.entity.Entity; // 添加Entity导入
import org.bukkit.event.entity.EntityDamageByEntityEvent; // 添加事件导入

public class PlayerActionListener implements Listener {
    private final AIChatPlugin plugin;
    private final Map<UUID, Long> lastMoveTime = new HashMap<>();
    private final Map<UUID, BukkitRunnable> afkTasks = new HashMap<>();
    private static final int AFK_THRESHOLD = 300; // 5分钟无操作视为发呆

    public PlayerActionListener(AIChatPlugin plugin) {
        this.plugin = plugin;
    }

    // 玩家加入服务器
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        String prompt = "玩家 " + player.getName() + " 加入了服务器";
        plugin.broadcastAIMessage(player, prompt);
    }

    // 工具损坏
    @EventHandler
    public void onItemBreak(PlayerItemBreakEvent event) {
        Player player = event.getPlayer();
        String itemName = event.getBrokenItem().getType().name();
        String prompt = "玩家 " + player.getName() + " 的" + itemName + "损坏了";
        plugin.broadcastAIMessage(player, prompt);
    }

    // 血量减少
    @EventHandler
    public void onPlayerDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player) {
            Player player = (Player) event.getEntity();
            // 记录伤害来源
            String damageCause = event.getCause().name();
            String damager = "未知";

            if (event instanceof EntityDamageByEntityEvent) { // 修复事件类型检查
                Entity damagerEntity = ((EntityDamageByEntityEvent) event).getDamager();
                damager = damagerEntity.getType().name();
            }

            // 存储伤害来源信息
            plugin.getPlayerDamageInfo().put(player.getUniqueId(),
                    new DamageInfo(damageCause, damager));
        }
    }

    // 玩家移动时重置AFK计时
    @EventHandler
    /**
     * 处理玩家动作事件。
     * 包括：
     * - 破坏方块
     * - 放置方块
     * - 交互事件
     */
    public void onPlayerMove(PlayerMoveEvent event) {
        // 仅当位置变化超过1格时处理
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to != null && (from.getBlockX() != to.getBlockX() ||
                from.getBlockZ() != to.getBlockZ())) {
            Player player = event.getPlayer();
            UUID playerId = player.getUniqueId();
            lastMoveTime.put(playerId, System.currentTimeMillis());

            // 取消已有的AFK任务
            if (afkTasks.containsKey(playerId)) {
                afkTasks.get(playerId).cancel();
                afkTasks.remove(playerId);
            }

            // 设置新的AFK检测任务
            BukkitRunnable task = new BukkitRunnable() {
                @Override
                public void run() {
                    if (!player.isOnline()) return;

                    long lastMove = lastMoveTime.getOrDefault(playerId, 0L);
                    if (System.currentTimeMillis() - lastMove > AFK_THRESHOLD * 1000) {
                        String prompt = "玩家 " + player.getName() + " 已经发呆5分钟了";
                        plugin.broadcastAIMessage(player, prompt);
                    }
                }
            };
            task.runTaskLater(plugin, AFK_THRESHOLD * 20); // 延时检测
            afkTasks.put(playerId, task);
        }
    }
}
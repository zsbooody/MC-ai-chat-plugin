/**
 * AIChatPlugin - Minecraft Bukkit插件
 * 
 * 这是一个集成AI聊天功能的Minecraft插件，主要功能包括：
 * 1. 玩家聊天AI响应
 * 2. 环境感知和空间探测
 * 3. 玩家状态监听
 * 4. 时间变化响应
 * 5. 配置管理和重载
 * 
 * 文件结构：
 * - 插件主类：负责初始化和协调各个组件
 * - 服务类：处理AI调用、环境感知等核心功能
 * - 监听器：处理游戏事件和玩家交互
 * - 工具类：提供通用功能支持
 */

package com.example.aichatplugin;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;
import org.bukkit.event.HandlerList;
import java.util.logging.Level;
import org.bukkit.configuration.file.FileConfiguration;
import java.util.logging.Logger;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerLevelChangeEvent;
import org.bukkit.event.player.PlayerAdvancementDoneEvent;

/**
 * AIChatPlugin主类
 * 
 * 职责：
 * 1. 插件生命周期管理
 * 2. 配置管理
 * 3. 服务初始化
 * 4. 事件监听器注册
 */
public class AIChatPlugin extends JavaPlugin {
    private AIService aiService;
    private EnvironmentCollector environmentCollector;
    private PlayerProfileManager profileManager;
    private PlayerStatusListener statusListener;
    private PlayerChatListener chatListener;
    private final Map<UUID, DamageInfo> playerDamageInfo = new ConcurrentHashMap<>();
    private ChatHistoryManager chatHistoryManager;
    
    @Override
    public void onEnable() {
        // 保存默认配置
        saveDefaultConfig();
        
        // 验证配置
        if (!validateConfig()) {
            getLogger().severe("配置验证失败，插件将被禁用！");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        
        // 初始化服务
        try {
            initializeServices();
            registerListeners();
            getLogger().info("AIChatPlugin已启用！");
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "初始化插件时发生错误", e);
            getServer().getPluginManager().disablePlugin(this);
        }
    }
    
    @Override
    public void onDisable() {
        if (aiService != null) {
            aiService.shutdown();
        }
        getLogger().info("AIChatPlugin已禁用！");
    }
    
    /**
     * 验证配置文件
     */
    private boolean validateConfig() {
        String apiKey = getConfig().getString("settings.api-key");
        if (apiKey == null || apiKey.isEmpty() || apiKey.equals("your-api-key-here")) {
            getLogger().severe("未配置API密钥！请在config.yml中设置settings.api-key");
            return false;
        }
        
        String model = getConfig().getString("settings.model");
        if (model == null || model.isEmpty()) {
            getLogger().severe("未配置AI模型！请在config.yml中设置settings.model");
            return false;
        }
        
        return true;
    }
    
    /**
     * 初始化服务
     */
    private void initializeServices() {
        // 初始化AI服务
        aiService = new DeepSeekAIService(this);
        
        // 初始化环境收集器
        environmentCollector = new EnvironmentCollector(this);
        
        // 初始化玩家档案管理器
        profileManager = new PlayerProfileManager(this, aiService);
        
        // 初始化对话历史管理器
        chatHistoryManager = new ChatHistoryManager(this);
        
        // 初始化状态监听器
        statusListener = new PlayerStatusListener(this, aiService, profileManager);
        
        // 初始化聊天监听器
        chatListener = new PlayerChatListener(this);
        
        debug("所有服务初始化完成");
    }
    
    /**
     * 注册事件监听器
     */
    private void registerListeners() {
        // 注册聊天监听器
        getServer().getPluginManager().registerEvents(chatListener, this);
        
        // 注册状态监听器
        getServer().getPluginManager().registerEvents(statusListener, this);
    }
    
    /**
     * 获取AI服务实例
     */
    public AIService getAIService() {
        return aiService;
    }
    
    /**
     * 获取环境收集器实例
     */
    public EnvironmentCollector getEnvironmentCollector() {
        return environmentCollector;
    }
    
    /**
     * 获取玩家档案管理器实例
     */
    public PlayerProfileManager getProfileManager() {
        return profileManager;
    }
    
    /**
     * 获取对话历史管理器实例
     */
    public ChatHistoryManager getChatHistoryManager() {
        return chatHistoryManager;
    }
    
    /**
     * 输出调试信息
     */
    public void debug(String message) {
        if (getConfig().getBoolean("debug.enabled", false)) {
            getLogger().info("[DEBUG] " + message);
        }
    }
    
    /**
     * 输出详细日志
     */
    public void verbose(String message) {
        if (getConfig().getBoolean("debug.verbose-logging", false)) {
            getLogger().info("[VERBOSE] " + message);
        }
    }
    
    /**
     * 广播AI消息
     * 
     * @param player 目标玩家
     * @param message 消息内容
     */
    public void broadcastAIMessage(Player player, String message) {
        String format = getConfig().getString("messages.reply", "AI: %s");
        String formattedMessage = String.format(format, message);
        
        if (getConfig().getBoolean("messages.broadcast-to-all", false)) {
            Bukkit.broadcastMessage(formattedMessage);
        } else {
            player.sendMessage(formattedMessage);
        }
    }
    
    /**
     * 获取玩家物品栏内容
     * 
     * @param player 目标玩家
     * @return 物品栏内容的字符串表示
     */
    public static String getInventoryString(Player player) {
        ItemStack[] contents = player.getInventory().getContents();
        StringBuilder sb = new StringBuilder();
        for (ItemStack item : contents) {
            if (item != null && !item.getType().isAir()) {
                sb.append(item.getType().name())
                  .append("x")
                  .append(item.getAmount())
                  .append(", ");
            }
        }
        return sb.length() > 0 ? sb.substring(0, sb.length() - 2) : "空";
    }
    
    /**
     * 获取玩家伤害信息映射
     * 
     * @return 玩家UUID到伤害信息的映射
     */
    public Map<UUID, DamageInfo> getPlayerDamageInfo() {
        return playerDamageInfo;
    }
} 



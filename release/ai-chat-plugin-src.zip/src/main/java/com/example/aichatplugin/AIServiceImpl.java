package com.example.aichatplugin;

import org.bukkit.entity.Player;
import java.util.List;

/**
 * AI服务实现类
 * 负责处理AI请求和响应
 */
public class AIServiceImpl implements AIService {
    private final DeepSeekAIService deepSeekService;
    private final ConversationManager conversationManager;
    private final AIChatPlugin plugin;
    
    public AIServiceImpl(DeepSeekAIService deepSeekService, ConversationManager conversationManager, AIChatPlugin plugin) {
        this.deepSeekService = deepSeekService;
        this.conversationManager = conversationManager;
        this.plugin = plugin;
    }

    @Override
    public String generateResponse(String prompt, Player player) {
        try {
            // 获取对话历史
            List<String> history = conversationManager.getHistory(player);
            
            // 生成响应
            return deepSeekService.generateResponse(prompt, player);
        } catch (Exception e) {
            plugin.getLogger().severe("生成AI响应时发生错误: " + e.getMessage());
            return "抱歉，我现在无法回应。请稍后再试。";
        }
    }

    @Override
    public void shutdown() {
        // 清理资源
        conversationManager.clearAll();
    }
} 
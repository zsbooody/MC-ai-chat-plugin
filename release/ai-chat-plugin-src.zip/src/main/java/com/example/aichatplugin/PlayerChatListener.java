package com.example.aichatplugin;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.concurrent.CompletableFuture;
import org.bukkit.ChatColor;

/**
 * 玩家聊天监听器
 * 
 * 职责：
 * 1. 监听玩家聊天事件
 * 2. 异步处理AI响应
 * 3. 优化性能，减少主线程负担
 * 4. 广播AI对话
 * 5. 维护对话历史
 */
public class PlayerChatListener implements Listener {
    private final AIChatPlugin plugin;
    private final EnvironmentCollector environmentCollector;
    private final AIService aiService;
    private final ChatHistoryManager chatHistoryManager;
    private final String prefix;
    private final boolean enabled;
    private final boolean broadcastEnabled;
    private final String broadcastFormat;
    
    public PlayerChatListener(AIChatPlugin plugin) {
        this.plugin = plugin;
        this.environmentCollector = plugin.getEnvironmentCollector();
        this.aiService = plugin.getAIService();
        this.chatHistoryManager = plugin.getChatHistoryManager();
        this.prefix = plugin.getConfig().getString("chat.prefix", "");
        this.enabled = plugin.getConfig().getBoolean("chat.enabled", true);
        this.broadcastEnabled = plugin.getConfig().getBoolean("chat.broadcast", true);
        this.broadcastFormat = plugin.getConfig().getString("chat.broadcast-format", "&7[AI对话] &f{player}: {message}");
        
        plugin.debug("PlayerChatListener初始化完成");
        plugin.verbose("聊天前缀: " + (prefix.isEmpty() ? "无" : prefix));
        plugin.verbose("聊天功能: " + (enabled ? "启用" : "禁用"));
        plugin.verbose("广播功能: " + (broadcastEnabled ? "启用" : "禁用"));
    }
    
    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        if (!enabled) {
            return;
        }
        
        Player player = event.getPlayer();
        String message = event.getMessage();
        
        // 检查消息前缀
        if (!prefix.isEmpty() && !message.startsWith(prefix)) {
            return;
        }
        
        // 如果设置了前缀，移除前缀
        final String finalMessage = !prefix.isEmpty() ? message.substring(prefix.length()) : message;
        event.setCancelled(true);
        
        // 添加玩家消息到历史记录
        chatHistoryManager.addMessage(player.getUniqueId(), player.getName(), finalMessage, true);
        
        // 广播玩家消息
        if (broadcastEnabled) {
            String broadcastMessage = broadcastFormat
                .replace("{player}", player.getName())
                .replace("{message}", finalMessage);
            plugin.getServer().broadcastMessage(ChatColor.translateAlternateColorCodes('&', broadcastMessage));
        }
        
        // 异步处理AI响应
        CompletableFuture.runAsync(() -> {
            try {
                // 收集环境信息（在主线程中执行）
                String environmentInfo = new CompletableFuture<String>().completeAsync(() -> {
                    return environmentCollector.collectEnvironmentInfo(player);
                }, runnable -> plugin.getServer().getScheduler().runTask(plugin, runnable)).join();
                
                // 获取对话历史
                String chatHistory = chatHistoryManager.getRecentContext(player.getUniqueId());
                
                // 构建提示词，将玩家消息放在最前面，环境信息作为补充
                String prompt = String.format(
                    "%s\n\n" +
                    "玩家 %s 说：%s\n\n" +
                    "（以下是玩家周围的环境信息，仅供参考：\n%s）",
                    chatHistory,
                    player.getName(), finalMessage, environmentInfo);
                
                plugin.debug("发送提示词到AI: " + prompt);
                
                // 生成AI响应
                String aiResponse = aiService.generateResponse(prompt, player);
                
                // 移除AI响应中可能存在的"AI:"前缀
                if (aiResponse.startsWith("AI:")) {
                    aiResponse = aiResponse.substring(3).trim();
                }
                
                // 添加AI响应到历史记录
                chatHistoryManager.addMessage(player.getUniqueId(), "AI", aiResponse, false);
                
                // 在主线程中发送消息
                final String finalResponse = aiResponse;
                new BukkitRunnable() {
                    @Override
                    public void run() {
                        // 广播AI响应
                        String broadcastResponse = broadcastFormat
                            .replace("{player}", "AI")
                            .replace("{message}", finalResponse);
                        plugin.getServer().broadcastMessage(ChatColor.translateAlternateColorCodes('&', broadcastResponse));
                        
                        plugin.debug("已发送AI响应给玩家: " + player.getName());
                    }
                }.runTask(plugin);
                
            } catch (Exception e) {
                plugin.getLogger().severe("处理AI响应时发生错误: " + e.getMessage());
                e.printStackTrace();
                
                // 发送错误消息
                String errorMessage = plugin.getConfig().getString("messages.error", "&c错误&f: {text}")
                    .replace("{text}", "处理消息时发生错误，请稍后重试");
                player.sendMessage(errorMessage);
            }
        });
    }
}
